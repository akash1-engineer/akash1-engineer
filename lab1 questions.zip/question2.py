# declare two variable and print that which variable is largest using ternary
a=int(input("enter value of a :"))
b=int(input("enter value of b :"))
is_valid="a is largest" if b<a else "b is largest"
print(is_valid)
