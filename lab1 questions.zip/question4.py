# python program to find the area of triangle whose side are given
base=2
height=4
area_of_triangle=(1/2)*base*height
print("area of triangle is :",area_of_triangle)