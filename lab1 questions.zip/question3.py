# python program to covert the temperature in degree centigrade to fahrenheit
temp_in_celsius=int(input("give me temperature in celsius :"))
temp_in_fehrenheit=(temp_in_celsius*1.8)+32
print("temperature convert successfuly in celsius to fehrenheit :",temp_in_fehrenheit)