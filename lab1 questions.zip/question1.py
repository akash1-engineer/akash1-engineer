# calulate the multiplication and sum of two numbers
num1=int(input("give fist number: "))
num2=int(input("give second number: "))
addition=num1+num2
multiplication=num1*num2
print("Addition of two number is :",addition)
print("multiplication of two number is ",multiplication)